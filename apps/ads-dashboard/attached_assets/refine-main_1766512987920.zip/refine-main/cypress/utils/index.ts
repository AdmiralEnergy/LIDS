export * from "./getIdFromURL";
