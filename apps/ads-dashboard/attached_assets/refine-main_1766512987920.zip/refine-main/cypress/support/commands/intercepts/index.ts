// add commands to the Cypress chain
import "./api-fake-rest";
import "./supabase";
import "./strapi-v4";
import "./hasura";
