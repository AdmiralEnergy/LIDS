export const hasuraBlogPosts = {
  data: {
    blog_posts: [
      {
        id: "1",
        title: "Sed ante. Vivamus tortor. Duis mattis egestas metus.",
        category: {
          id: "1",
          title: "neque vestibulum",
        },
        category_id: "1",
        content:
          "Phasellus sit amet erat. Nulla tempus. Vivamus in felis eu sapien cursus vestibulum.",
        created_at: "2023-03-20T09:57:27.548697+00:00",
      },
      {
        id: "2",
        title: "Phasellus sit amet erat.",
        category: {
          id: "2",
          title: "enim lorem ipsum",
        },
        category_id: "2",
        content:
          "Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.\n\nIn hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.\n\nAliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.",
        created_at: "2023-03-20T09:57:27.548697+00:00",
      },
      {
        id: "3",
        title:
          "Nam ultrices, libero non mattis pulvinar, nulla pede ullamcorper augue, a suscipit nulla elit ac nulla. Sed vel enim sit amet nunc viverra dapibus.",
        category: {
          id: "3",
          title: "vivamus vel",
        },
        category_id: "3",
        content:
          "Suspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.\n\nMaecenas ut massa quis augue luctus tincidunt. Nulla mollis molestie lorem. Quisque ut erat.",
        created_at: "2023-03-20T09:57:27.548697+00:00",
      },
      {
        id: "4",
        title:
          "Suspendisse potenti. In eleifend quam a odio. In hac habitasse platea dictumst.",
        category: {
          id: "4",
          title: "aaaaaaaaaarhoncus",
        },
        category_id: "4",
        content:
          "Proin leo odio, porttitor id, consequat in, consequat ut, nulla. Sed accumsan felis. Ut at dolor quis odio consequat varius.",
        created_at: "2023-03-20T09:57:27.548697+00:00",
      },
      {
        id: "5",
        title:
          "In hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.",
        category: {
          id: "5",
          title: "turpis adipiscing lorem",
        },
        category_id: "5",
        content:
          "Duis consequat dui nec nisi volutpat eleifend. Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus.\n\nMauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.\n\nNullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.",
        created_at: "2023-03-20T09:57:27.548697+00:00",
      },
      {
        id: "6",
        title:
          "Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.",
        category: {
          id: "6",
          title: "aaaaaaaaaaaaaaaaaaaaaaaaaaaa",
        },
        category_id: "6",
        content:
          "Vestibulum quam sapien, varius ut, blandit non, interdum in, ante. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Duis faucibus accumsan odio. Curabitur convallis.\n\nDuis consequat dui nec nisi volutpat eleifend. Donec ut dolor. Morbi vel lectus in quam fringilla rhoncus.\n\nMauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci. Mauris lacinia sapien quis libero.",
        created_at: "2023-03-20T09:57:27.548697+00:00",
      },
      {
        id: "7",
        title: "Etiam pretium iaculis justo.",
        category: {
          id: "7",
          title: "test category",
        },
        category_id: "7",
        content:
          "In congue. Etiam justo. Etiam pretium iaculis justo.\n\nIn hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.\n\nNulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.",
        created_at: "2023-03-20T09:57:27.548697+00:00",
      },
      {
        id: "8",
        title: "Pellentesque at nulla. Suspendisse potenti.",
        category: {
          id: "8",
          title: "vulputate elementum nullam 2",
        },
        category_id: "8",
        content:
          "Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.",
        created_at: "2023-03-20T09:57:27.548697+00:00",
      },
      {
        id: "9",
        title:
          "Integer ac neque. Duis bibendum. Morbi non quam nec dui luctus rutrum.",
        category: {
          id: "9",
          title: "lacinia eget tincidunt",
        },
        category_id: "9",
        content:
          "Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.",
        created_at: "2023-03-20T09:57:27.548697+00:00",
      },
      {
        id: "10",
        title:
          "Aliquam non mauris. Morbi non lectus. Aliquam sit amet diam in magna bibendum imperdiet.",
        category: {
          id: "10",
          title: "aliquam erat volutpat",
        },
        category_id: "10",
        content:
          "In hac habitasse platea dictumst. Etiam faucibus cursus urna. Ut tellus.Nulla ut erat id mauris vulputate elementum. Nullam varius. Nulla facilisi.",
        created_at: "2023-03-20T09:57:27.548697+00:00",
      },
      {
        id: "11",
        title: "Praesent lectus.",
        category: {
          id: "1",
          title: "aaaaaaaaaarhoncus",
        },
        category_id: "1",
        content:
          "Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.\n\nProin interdum mauris non ligula pellentesque ultrices. Phasellus id sapien in sapien iaculis congue. Vivamus metus arcu, adipiscing molestie, hendrerit at, vulputate vitae, nisl.",
        created_at: "2023-03-20T09:57:27.548697+00:00",
      },
      {
        id: "12",
        title:
          "Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis. Fusce posuere felis sed lacus.",
        category: {
          id: "2",
          title: "vulputate elementum nullam 2",
        },
        category_id: "2",
        content:
          "Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.\n\nSed ante. Vivamus tortor. Duis mattis egestas metus.\n\nAenean fermentum. Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.",
        created_at: "2023-03-20T09:57:27.548697+00:00",
      },
      {
        id: "13",
        title:
          "Donec ut mauris eget massa tempor convallis. Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh.",
        category: {
          id: "3",
          title: "sed accumsan felis",
        },
        category_id: "3",
        content:
          "Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.\n\nDonec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.",
        created_at: "2023-03-20T09:57:27.548697+00:00",
      },
      {
        id: "14",
        title:
          "Praesent blandit. Nam nulla. Integer pede justo, lacinia eget, tincidunt eget, tempus vel, pede.",
        category: {
          id: "4",
          title: "enim lorem ipsum",
        },
        category_id: "4",
        content:
          "Morbi non lectus. Aliquam sit amet diam in magna bibendum imperdiet. Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.\n\nFusce posuere felis sed lacus. Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl. Nunc rhoncus dui vel sem.",
        created_at: "2023-03-20T09:57:27.548697+00:00",
      },
      {
        id: "15",
        title:
          "In hac habitasse platea dictumst. Maecenas ut massa quis augue luctus tincidunt.",
        category: {
          id: "5",
          title: "vulputate elementum nullam 2",
        },
        category_id: "5",
        content:
          "Pellentesque at nulla. Suspendisse potenti. Cras in purus eu magna vulputate luctus.\n\nCum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus vestibulum sagittis sapien. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.",
        created_at: "2023-03-20T09:57:27.548697+00:00",
      },
      {
        id: "16",
        title: "Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo.",
        category: {
          id: "6",
          title: "blandit ultrices enim",
        },
        category_id: "6",
        content:
          "Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum.\n\nIn hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.",
        created_at: "2023-03-20T09:57:27.548697+00:00",
      },
      {
        id: "17",
        title: "Praesent lectus.",
        category: {
          id: "7",
          title: "amet turpis elementum",
        },
        category_id: "7",
        content:
          "In hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante. Nulla justo.",
        created_at: "2023-03-20T09:57:27.548697+00:00",
      },
      {
        id: "18",
        title: "Proin risus. Praesent lectus.",
        category: {
          id: "8",
          title: "ipsum primis in",
        },
        category_id: "8",
        content:
          "Etiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.\n\nPraesent id massa id nisl venenatis lacinia. Aenean sit amet justo. Morbi ut odio.",
        created_at: "2023-03-20T09:57:27.548697+00:00",
      },
      {
        id: "19",
        title: "Integer non velit.",
        category: {
          id: "9",
          title: "lorem integer tincidunt",
        },
        category_id: "9",
        content:
          "Fusce posuere felis sed lacus. Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl. Nunc rhoncus dui vel sem.\n\nSed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.\n\nPellentesque at nulla. Suspendisse potenti. Cras in purus eu magna vulputate luctus.",
        created_at: "2023-03-20T09:57:27.548697+00:00",
      },
      {
        id: "20",
        title:
          "Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci.",
        category: {
          id: "10",
          title: "HK",
        },
        category_id: "10",
        content:
          "Duis aliquam convallis nunc. Proin at turpis a pede posuere nonummy. Integer non velit.\n\nDonec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.\n\nDuis bibendum. Morbi non quam nec dui luctus rutrum. Nulla tellus.",
        created_at: "2023-03-20T09:57:27.548697+00:00",
      },
    ],
    blog_posts_aggregate: {
      aggregate: {
        count: 20,
      },
    },
  },
};
