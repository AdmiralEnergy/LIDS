export const hasuraCategories = {
  data: {
    categories: [
      {
        id: "1",
        title: "aliquam erat volutpat",
        created_at: "2022-12-26T08:10:16.962584+00:00",
      },
      {
        id: "2",
        title: "volutpat in congue",
        created_at: "2022-12-26T08:10:16.962584+00:00",
      },
      {
        id: "3",
        title: "enim lorem ipsum",
        created_at: "2022-12-26T08:10:16.962584+00:00",
      },
      {
        id: "4",
        title: "ornare consequat lectus in",
        created_at: "2022-12-26T08:10:16.962584+00:00",
      },
      {
        id: "5",
        title: "vestibulum rutrum rutrum",
        created_at: "2022-12-26T08:10:16.962584+00:00",
      },
      {
        id: "6",
        title: "blandit ultrices enim",
        created_at: "2022-12-26T08:10:16.962584+00:00",
      },
      {
        id: "7",
        title: "lacinia eget tincidunt",
        created_at: "2022-12-26T08:10:16.962584+00:00",
      },
      {
        id: "8",
        title: "amet turpis elementum",
        created_at: "2022-12-26T08:10:16.962584+00:00",
      },
      {
        id: "9",
        title: "sed accumsan felis",
        created_at: "2022-12-26T08:10:16.962584+00:00",
      },
      {
        id: "10",
        title: "ipsum primis in",
        created_at: "2022-12-26T08:10:16.962584+00:00",
      },
    ],
    categories_aggregate: {
      aggregate: {
        count: 10,
      },
    },
  },
};
