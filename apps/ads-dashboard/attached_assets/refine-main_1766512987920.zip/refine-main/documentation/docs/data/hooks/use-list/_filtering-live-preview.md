```css live shared
body {
  padding: 4px;
  background: white;
}
```

```tsx live url=http://localhost:3000/products previewHeight=300px hideCode
setInitialRoutes(["/products"]);

// visible-block-start
import { useState } from "react";
import { useList, HttpError } from "@refinedev/core";

interface IProduct {
  id: number;
  name: string;
  material: string;
}

const ProductList: React.FC = () => {
  //highlight-next-line
  const [value, setValue] = useState("Cotton");

  const { result, query } = useList<IProduct, HttpError>({
    resource: "products",
    //highlight-start
    filters: [
      {
        field: "material",
        operator: "eq",
        value,
      },
    ],
    //highlight-end
  });

  const products = result.data ?? [];

  if (query.isLoading) {
    return <div>Loading...</div>;
  }

  if (query.isError) {
    return <div>Something went wrong!</div>;
  }

  return (
    <div>
      {/* highlight-start */}
      <span> material: </span>
      <select value={value} onChange={(e) => setValue(e.target.value)}>
        {["Cotton", "Bronze", "Plastic"].map((material) => (
          <option key={material} value={material}>
            {material}
          </option>
        ))}
      </select>
      {/* highlight-end */}

      <ul>
        {products.map((product) => (
          <li key={product.id}>
            <h4>
              {product.name} - ({product.material})
            </h4>
          </li>
        ))}
      </ul>
    </div>
  );
};

// visible-block-end

setRefineProps({
  resources: [
    {
      name: "products",
      list: "/products",
    },
  ],
});

render(
  <ReactRouter.BrowserRouter>
    <RefineHeadlessDemo>
      <ReactRouter.Routes>
        <ReactRouter.Route path="/products" element={<ProductList />} />
      </ReactRouter.Routes>
    </RefineHeadlessDemo>
  </ReactRouter.BrowserRouter>,
);
```
