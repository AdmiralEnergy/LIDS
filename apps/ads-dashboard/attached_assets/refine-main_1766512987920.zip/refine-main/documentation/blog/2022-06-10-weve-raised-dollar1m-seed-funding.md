---
title: We’ve raised $1M in Seed Funding! 🚀 🚀 🚀
slug: weve-raised-dollar1m-seed-funding
image: https://refine.ams3.cdn.digitaloceanspaces.com/blog/2022-06-10-weve-raised-dollar1m-seed-funding/refine-500-2.png
authors: necati
tags: [community]
hide_table_of_contents: false
---

We are very excited to announce that Refine has raised $1M in our first round led by [500 Istanbul](https://istanbul.500.co/).

First of all, we want to give a special thanks ❤️ to the open source community who supported us along the way. We couldn’t have done it without you!

<img src="https://refine.ams3.cdn.digitaloceanspaces.com/blog/2022-06-10-weve-raised-dollar1m-seed-funding/refine-500.png" alt="Refine - 500" />

<!--truncate-->

We have also some good friends on board as angel investors: Emre Baran, Founder of Cerbos and Burak Emre Kabakcı, Founder of Rakam. Welcome to the Refine family!

This funding will enable the core team to solely focus on Refine providing new features, frequent updates and support for the community. We’ll also able to grow our team and accelerate our product roadmap.

You can follow our new company profile on [Linkedin](https://www.linkedin.com/company/refine-dev) for official announcements and job opportunities.

Stay tuned for more updates as we continue growing and developing Refine. Thanks for your support!
